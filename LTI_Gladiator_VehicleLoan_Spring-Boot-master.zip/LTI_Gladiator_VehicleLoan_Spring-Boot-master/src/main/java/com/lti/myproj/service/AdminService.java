package com.lti.myproj.service;

public interface AdminService {
	
	

}
