package com.lti.myproj.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.myproj.repository.AdminRepository;

@Service
@Scope
@Transactional

public class AdminServiceImpl {

	
	

}
