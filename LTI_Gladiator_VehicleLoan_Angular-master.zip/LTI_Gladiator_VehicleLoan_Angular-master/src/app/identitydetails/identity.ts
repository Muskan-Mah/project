export class identity{
    aadharNumber:number=0;
    panNumber:string="";
}