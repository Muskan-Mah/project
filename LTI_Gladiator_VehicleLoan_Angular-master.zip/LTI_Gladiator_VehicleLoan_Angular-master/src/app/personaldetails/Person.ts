export class Person{
    customerId:number=0;
    firstName:string="";
    age:number=0;
    gender:string="";
    email:string="";
    mobile:number=0;
    state:string="";
    city:string="";
}