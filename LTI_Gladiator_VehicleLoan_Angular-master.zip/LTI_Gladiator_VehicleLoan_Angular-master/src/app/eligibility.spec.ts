import { Eligibility } from './eligibility';

describe('Eligibility', () => {
  it('should create an instance', () => {
    expect(new Eligibility()).toBeTruthy();
  });
});
