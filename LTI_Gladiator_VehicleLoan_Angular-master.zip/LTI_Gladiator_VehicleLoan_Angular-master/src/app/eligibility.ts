export class Eligibility {
    fname:string|undefined;
    mname:string|undefined;
    lname:string|undefined;
    age:number|undefined;
    gender:string|undefined;
    employment:string|undefined;
    typeofemployment:string|undefined;
    annualincome:number|undefined;
    existingemi:number|undefined;
    mobileno:number|undefined;
    emailid:string|undefined;

}
