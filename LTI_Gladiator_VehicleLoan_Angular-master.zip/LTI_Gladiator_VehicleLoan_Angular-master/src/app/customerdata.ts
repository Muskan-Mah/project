export class customerdata{
    constructor(){}

    customerId:number=0;
        firstName:string="";
        age:number=0;
        gender:string="";
        email:string="";
        mobile:number=0;
        state:string="";
        city:string="";
        aadharNumber:number=0;
        panNumber:string="";
    
  }